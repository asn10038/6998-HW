You must have flask installed to run this application

Tun this code in the terminal with 
python server.py

go to localhost:5000/infinity
or /ppc

You should see things!