from flask import Flask
from flask import render_template
from flask import Response, request, jsonify
app = Flask(__name__)


# INFINITY
current_id = 4

sales = [
    {
        "id": 1, 
        "salesperson": "James D. Halpert",
        "client": "Shake Shack",
        "reams": 1000
    },
    {
        "id": 2, 
        "salesperson": "Stanley Hudson",
        "client": "Toast",
        "reams": 4000
    },
    {
        "id": 3, 
        "salesperson": "Michael G. Scott",
        "client": "Computer Science Department",
        "reams": 10000
    },
]


clients = [
    "Shake Shack",
    "Toast",
    "Computer Science Department",
    "Teacher's College",
    "Starbucks",
    "Subsconsious",
    "Flat Top",
    "Joe's Coffee",
    "Max Caffe",
    "Nussbaum & Wu",
    "Taco Bell",
];




@app.route('/')
def hello_world():
   return 'Hello World'

@app.route('/infinity')
def infinity():
   return render_template('cu-paper-infinity.html', sales = sales, clients = clients)

@app.route('/save_sale', methods=['GET', 'POST'])
def save_sale():
    print("save_sale")
    global sales
    global clients
    global current_id   

    #UPDATES SALES
    sale_data = request.get_json()    
    sale_data["id"] = current_id
    current_id += 1
    #prepend the new sale to the sales data.
    #sales = [sale_data] + sales
    sales.append(sale_data)

    #UPDATE CLIENTS
    sale_client = sale_data["client"]
    if sale_client not in clients:
        clients.append(sale_client)
        print("added to clients: "+sale_client)
    else:
        print("did NOT add client: "+ sale_client)


    return jsonify(sales = sales, clients = clients)


@app.route('/delete_sale', methods=['GET', 'POST'])
def delete_sale():
    print("delete_sale")
    global sales
    global client
    #global current_id   


    id_json = request.get_json()
    print(id_json)
    #sale_data["id"] = current_id
    
    delete_id = int(id_json["id"])
    print(delete_id)

    # find the sales record with this id, and delete it.
    index_to_delete = None
    for (i, s) in enumerate(sales):
        s_id = s["id"]
        print(s["id"])
        if s_id == delete_id:
            print("found it: ")
            print(i, s)
            index_to_delete = i

            break


    if index_to_delete is not None:
        print("deleting: ", index_to_delete)
        del sales[index_to_delete]
    
    print("new sales array")
    print(sales)


    #sales.append(sale_data)

    return jsonify(sales = sales)




#PARTY PLANNING COMMITTEE
non_ppc_people = [
"Phyllis",
"Dwight",
"Oscar",
"Creed",
"Pam",
"Jim",
"Stanley",
"Michael",
"Kevin",
"Kelly"
]


ppc_people = [
"Angela"
]



@app.route('/ppc')
def ppc():
   return render_template('ppc.html', names=non_ppc_people, list1=ppc_people) #2_ppc


@app.route('/move_to_ppc', methods=['GET', 'POST'])
def move_to_ppc():
    print("move_to_ppc")
    global non_ppc_people
    global ppc_people
    #global current_id 

    json_data = request.get_json()  
    name = json_data["name"]

    #remove name from non_ppc_people
    non_ppc_people.remove(name)

    #move to ppc
    ppc_people.append(name)


    return jsonify(names=non_ppc_people, list1=ppc_people)


@app.route('/move_to_non_ppc', methods=['GET', 'POST'])
def move_to_non_ppc():
    print("move_to_non_ppc")
    global non_ppc_people
    global ppc_people
    #global current_id 

    json_data = request.get_json()  
    name = json_data["name"]

    #remove name from non_ppc_people
    ppc_people.remove(name)

    #move to ppc
    non_ppc_people.append(name)


    return jsonify(names=non_ppc_people, list1=ppc_people)

'''
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name) 

@app.route('/people')
def people(name=None):
    return render_template('people.html', data=data)  


@app.route('/save_data', methods=['GET', 'POST'])
def save_data():
    global data    
    user_data = request.get_json()
    data = user_data
    return jsonify(data)
'''
      

if __name__ == '__main__':
   app.run(debug=True)




